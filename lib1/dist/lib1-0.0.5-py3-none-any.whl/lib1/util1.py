def archive_something():
    print("Archiving something...")

def archive_something_more():
    print("Archiving something more...")

def function_only_in_version_gt_0_0_4():
    print("function_only_in_version_gt_0_0_4")
