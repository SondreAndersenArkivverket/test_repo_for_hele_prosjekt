# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lib1']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'lib1',
    'version': '0.0.5',
    'description': '',
    'long_description': '# Test shared library\n\n\n# Push new code\n\nWe store the code for this package in a subdirectory of our project repository.\n\nAll functions or classes that is to be a part of the package must be imported in the `__init__.py` file.\n\nWhen we want to deploy a new version of the package we need to commit the changes to the `main` branch in Github, and then\nrun the code in [`Makefile`](Makefile) in order to change the version number and tag the new commit with a new version number. This can be done by\nrunning `make version v=<version number>`.\n\nMakefile:\n```make\nversion:\n\t@poetry version $(v)\n\t@git add pyproject.toml\n\t@git commit -m "v$$(poetry version -s)"\n\t@git tag v$$(poetry version -s)\n\t@git push\n\t@git push --tags\n\t@poetry version\n```\n\nNote: We need a version tag to be able to specify which version of the package we want. -> https://stackoverflow.com/a/55526482\n\n\n# Poetry\n\nUsing this package with Poetry.\n\n## How to install with Poetry\n\n```\n[tool.poetry.dependencies]\n...\nlib1 = {git = "git@github.com:SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git", subdirectory = "lib1"}\n```\n\n## Install specific version\n\nThe version of the package we want to install can be specified with `rev = "vx.x.x`:\n\n```\n[tool.poetry.dependencies]\n...\nlib1 = { git = "git@github.com:SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git", subdirectory = "lib1", rev = "v0.0.1" }\n```\n\n## How to get the newest version of this package\n\nRun: `poetry update`\n\n\n# How to PIP install this\n\n*Have not been able to make this work yet.*\n\n*Notes:*\n- Tried: `pip install -e git+ssh://git@github.com/SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git@main#egg=lib1&subdirectory=lib1`\n- Tried: `pip install git+ssh://git@github.com/SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git@main#egg=lib1&subdirectory=lib1`\n- Tried: `pip install "git+https://github.com/SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git@main#egg=lib1&subdirectory=lib1"`\n- Worked: `pip install "git+https://github.com/SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git@main#egg=lib1&#subdirectory=lib1"`\n- Testing now: `pip install git+ssh://git@github.com/SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git@main#egg=lib1#subdirectory=lib1`\n\n\n\nhttps://github.com/python-poetry/poetry/issues/755#issuecomment-451000247\n\n**Med token:**\n```sh\npip install -e git+https://<token>@github.com/<user>/<repo>.git@<branch>#egg=<package>&subdirectory=src\n```\n\n**Uten token:**\n```sh\npip install -e git+https://github.com/SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git@main#subdirectory=lib1\n```\n\nObs. `-e` means editable, so that means it always get the newest version from Github! (Might not be what we want?)\n\n\n\n\n# Sources\n\n- How to add this repo: https://stackoverflow.com/a/59718369\n\n- https://dev.to/luscasleo/creating-and-publishing-a-python-lib-with-poetry-and-git-11bp\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
