def helper_function():
    print("Helper function")

