# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lib1']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'lib1',
    'version': '0.0.8',
    'description': '',
    'long_description': '# Test shared library\n\n\n# Push new code\n\nWe store the code for this package in a subdirectory of our project repository.\n\nAll functions or classes that is to be a part of the package must be imported in the `__init__.py` file.\n\nWhen we want to deploy a new version of the package we need to commit the changes to the `main` branch in Github, and then run the code in [`release_new_version`](release_new_version.sh), while being in the main branch, in order to change the version number and tag the new commit with a new version number. This can be done by running `./release_new_version.sh x.x.x`, where `x.x.x` is a placeholder for the new version we want to release.\n\n\nNote: We need a version tag to be able to specify which version of the package we want. -> https://stackoverflow.com/a/55526482\n\n\n# Poetry\n\nUsing this package with Poetry.\n\n## How to install with Poetry\n\n```\n[tool.poetry.dependencies]\n...\nlib1 = {git = "git@github.com:SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git", subdirectory = "lib1"}\n```\n\n## Install specific version\n\nThe version of the package we want to install can be specified with `rev = "vx.x.x`:\n\n```\n[tool.poetry.dependencies]\n...\nlib1 = { git = "git@github.com:SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git", subdirectory = "lib1", rev = "v0.0.8" }\n```\n\n## How to get the newest version of this package\n\nRun: `poetry update`\n\n\n# How to PIP install this\n\n`pip install "git+ssh://git@github.com/SondreAndersenArkivverket/test_repo_for_hele_prosjekt.git@v0.0.8#egg=lib1&#subdirectory=lib1"`\n\nThis command installs the python package from the `pyproject.toml` file, and does NOT use `.whl`. I have tried, but have not been able to make `.whl` packages work yet.\n\n# Versions\n\nWe should probably use something like: https://en.wikipedia.org/wiki/Software_versioning#Semantic_versioning\n\n# Sources\n\n- How to add this repo: https://stackoverflow.com/a/59718369\n\n- https://dev.to/luscasleo/creating-and-publishing-a-python-lib-with-poetry-and-git-11bp\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
